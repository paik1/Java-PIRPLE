/*
 * Below are the attributes to one of my favourite song
 * The name of this song is "Makasam" by the Indian artist kr$na
 */
package favouritesong;


public class FavouriteSong {

    public static void main(String[] args) {
        
        String Name = "Makasam";
        int YearReleased = 2020;
        String Artist = "Kr$na";
        char ArtistLogo = '$';
        float SongLength = 5.38f;
        int Views = 7006957;
        String Label = "Kalamkaar";
        String Genre = "hip-hop";
        double Likes = 206;
        
        System.out.println(Name);
        System.out.println(YearReleased);
        System.out.println(Artist);
        System.out.println(ArtistLogo);
        System.out.println(SongLength);
        System.out.println(Views);
        System.out.println(Label);
        System.out.println(Genre);
        System.out.println(Likes);
        
    }
    
}
